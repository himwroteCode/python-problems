n=int(input(" enter non negative number ; "))

for i in range(n):
    print(i*i)

    